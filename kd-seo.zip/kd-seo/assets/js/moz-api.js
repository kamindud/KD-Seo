class kdMozApi{
    
}