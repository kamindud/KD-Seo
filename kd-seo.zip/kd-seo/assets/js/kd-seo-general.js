class kdGeneralSettings {
    googleApiKey = null;
    googleCx = null;
    mozApiId = null;
    mozApiSecret = null;

    // get admin options
    kdGetOptions = () => {
        let homeUrl = window.kdInfo.homeUrl;
        let http = new XMLHttpRequest();
        http.open('GET', `${homeUrl}/wp-json/kd-seo/v1/options`);
        http.onload = () => {
            if (http.status === 200) {
                let data = JSON.parse(http.responseText);
                this.googleApiKey = data['google-key'];
                this.googleCx = data['google-cx'];
                this.mozApiId = data['moz-id'];
                this.mozApiSecret = data['moz-secret'];
            }
        }
        http.send();
    }

    // return admin options
    kdGetOtions(what) {
        let requestedOption = this.googleApiKey;
        switch (what) {
            case 'google-cx':
                requestedOption = this.googleCx;
                break;
            case 'moz-id':
                requestedOption = this.mozApiId;
                break;
            case 'moz-secret':
                requestedOption = this.mozApiSecret;
                break;
            default:
                requestedOption = this.googleApiKey;
                break;
        }
        return requestedOption;
    }

    // get googles data
    getGoogleIndexing(kdKWorDomain , kdKWorCountry) {
        const googleApiInstance = new kdGoogleApi(this.googleApiKey , this.googleCx , kdKWorCountry , kdKWorDomain);
    }

    // get moz Url Data
    getMozUrlData(kdKWorDomain) {
        const googleApiInstance = new kdMozApi();
    }

    // verify seo form input
    verifyInput(kdKWorDomain , kdKWorCountry) {
        if (kdKWorDomain.indexOf("https://") !== -1 || kdKWorDomain.indexOf("http://") !== -1 || kdKWorDomain.indexOf("www.") !== -1) {
            this.getMozUrlData(kdKWorDomain);
        } else {
            this.getGoogleIndexing(kdKWorDomain , kdKWorCountry);
        }
    };
}

// init kdGoogleApi class 
let kdGeneralSettingsInstance = new kdGeneralSettings();

//=================== get options =============================
document.addEventListener('DOMContentLoaded', () => {
    kdGeneralSettingsInstance.kdGetOptions();
})

//===================== main form submit ============================
window.addEventListener('load', () => {
    // add form submit event
    let kdSearchForm = document.getElementById('kd-seo-search-form');

    if (kdSearchForm !== null) {
        // add form event listener
        kdSearchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            let kdKWorDomain = document.getElementById('kd-main-search-kw-domain').value;
            let kdKWorCountry = document.getElementById('kd-main-search-country-code').value;
            kdGeneralSettingsInstance.verifyInput(kdKWorDomain , kdKWorCountry);
        })
    }
})