<?php 

class Kd_Rest_api{

    public function kd_get_options(){
        $kd_options_arr = [];
        $kd_options_arr['google-key'] = get_option('kd_seo_google_api_key');
        $kd_options_arr['google-cx'] = get_option('kd_seo_google_cx_code');
        $kd_options_arr['moz-id'] = get_option('kd_seo_moz_api_id');
        $kd_options_arr['moz-secret'] = get_option('kd_seo_moz_api_secret');
        return $kd_options_arr;
    }

    public function kd_create_options_rest(){
        register_rest_route( 'kd-seo/v1', 'options',  array(
            'methods'  => 'GET',
            'callback' => array($this,'kd_get_options')
        ));
    }

}
