<?php

/* Plugin Name: KD SEO TOOL
* Plugin URI:        https://kamindudushmantha.com/seo-tool-plugin
 * Description:       Seo report generator plugin for wordpress
 * Version:           1.0.0
 * Author:            Kamindu Dushmantha
 * Author URI:        https://kamindudushmantha.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       'kd_seo'
 * Domain Path:       /languages */

//  ========================================================import pages==========================================
require_once('lib/classes/settings.php');
require_once('lib/classes/restapi.php');
require_once('lib/classes/frontend.php');

// ========================================================initiate classes==========================================
$kd_settings = new Kd_seo_settings();
$kd_frontend = new Kd_Seo_frontend();
$kd_restapi = new Kd_Rest_api();

// ========================================================functions==========================================

// create setting group
function kd_seo_register_settings()
{
    global $kd_settings;
    $kd_settings->kd_seo_create_settings_page();
}

// create settings page
function kd_seo_register_options_page()
{
    global $kd_settings;
    $kd_settings->kd_seo_register_options_page();
}

// create frontend
function kd_seo_create_frontend()
{
    global $kd_frontend;
    return $kd_frontend->kd_seo_create_shortcode();
}

// enqueue scripts
function kd_seo_enqueue_scripts()
{
    // enqueue styles
    wp_enqueue_style('kd-seo-frontend-style', plugins_url('/assets/css/ui.css', __FILE__));

    wp_enqueue_script('kd-seo-google-script', plugins_url('/assets/js/google-api.js', __FILE__), array(), '', true);
    wp_enqueue_script('kd-seo-moz-script', plugins_url('/assets/js/moz-api.js', __FILE__), array(), '', true);
    wp_register_script('kd-seo-general', plugins_url('/assets/js/kd-seo-general.js', __FILE__), array(), '', true);
    wp_localize_script('kd-seo-general', 'kdInfo', array('homeUrl' => esc_url(home_url())));
    wp_enqueue_script('kd-seo-general');

    // echo website's url
    echo '<script></script>';
}

// create custom rest routes
function kd_create_custom_rest_routes()
{
    global $kd_restapi;
    $kd_restapi->kd_create_options_rest();
}

// ========================================================shortcodes==========================================

add_shortcode('kd-seo-tool', 'kd_seo_create_frontend');

// ========================================================action hooks==========================================

// creating a settings page
add_action('admin_menu', 'kd_seo_register_options_page');
add_action('admin_init', 'kd_seo_register_settings');
// enqueue scripts
add_action('wp_enqueue_scripts', 'kd_seo_enqueue_scripts');
// create rest routes
add_action('rest_api_init', 'kd_create_custom_rest_routes');

// ========================================================filter hooks==========================================
