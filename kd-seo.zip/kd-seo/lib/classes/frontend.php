<?php 

class Kd_Seo_frontend{

    public function kd_seo_create_shortcode(){
        $kd_front_page_content = file_get_contents(plugin_dir_url(__FILE__).'../templates/frontpage.html');
        return $kd_front_page_content;
    }
}



