<?php

function kd_seo_options_page()
{
?>
    <div>
        <?php screen_icon(); ?>
        <h1>KD SEO Settings</h1>
        <h3>Place this shortcode in the page where you need this module to be placed. <b>"[kd-seo-tool]"</b></h3>
        <br>
        <form method="post" action="options.php">
            <?php settings_fields('kd_seo_options_group'); ?>
            <h3>Google developer api key</h3>
            <p><a href="#">How to get google api key</a></p>
            <table>
                <tr valign="top">
                    <th scope="row"><label for="kd_seo_google_api_key">Google Api Key</label></th>
                    <td><input type="text" id="kd_seo_google_api_key" name="kd_seo_google_api_key" value="<?php echo get_option('kd_seo_google_api_key'); ?>" /></td>
                </tr>
            </table>
            <hr>
            <h3>Google custom search CX code</h3>
            <p><a href="#">How to get google cx code</a></p>
            <table>
                <tr valign="top">
                    <th scope="row"><label for="kd_seo_google_cx_code">Google Custom Search CX Code</label></th>
                    <td><input type="text" id="kd_seo_google_cx_code" name="kd_seo_google_cx_code" value="<?php echo get_option('kd_seo_google_cx_code'); ?>" /></td>
                </tr>
            </table>
            <hr>
            <h3>Moz API Access ID</h3>
            <p><a href="#">How to get moz api access ID</a></p>
            <table>
                <tr valign="top">
                    <th scope="row"><label for="kd_seo_moz_api_id">Moz Api Access ID</label></th>
                    <td><input type="text" id="kd_seo_moz_api_id" name="kd_seo_moz_api_id" value="<?php echo get_option('kd_seo_moz_api_id'); ?>" /></td>
                </tr>
            </table>
            <hr>
            <h3>Moz API Secret key</h3>
            <p><a href="#">How to get moz api Secret key</a></p>
            <table>
                <tr valign="top">
                    <th scope="row"><label for="kd_seo_moz_api_secret">Moz Api secret Key</label></th>
                    <td><input type="text" id="kd_seo_moz_api_secret" name="kd_seo_moz_api_secret" value="<?php echo get_option('kd_seo_moz_api_secret'); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
<?php
}

class Kd_seo_settings
{
    public function kd_seo_create_settings_page()
    {
        // add options
        add_option('kd_seo_google_api_key', 'Google Api Key');
        add_option('kd_seo_google_cx_code', 'Google CX Code');
        add_option('kd_seo_moz_api_id', 'Moz Api Access ID');
        add_option('kd_seo_moz_api_secret', 'Moz Api Secret Key');

        // register settings
        register_setting('kd_seo_options_group', 'kd_seo_google_api_key');
        register_setting('kd_seo_options_group', 'kd_seo_google_cx_code');
        register_setting('kd_seo_options_group', 'kd_seo_moz_api_id');
        register_setting('kd_seo_options_group', 'kd_seo_moz_api_secret');
    }

    public function kd_seo_register_options_page()
    {
        add_options_page('KD SEO Settings', 'KD SEO Settings', 'manage_options', 'kd_seo_settings', 'kd_seo_options_page');
    }
}
