// google api class
class kdGoogleApi{

    constructor(googleApiKey , googleCx , country , keyword){
        console.log(googleApiKey , googleCx , keyword);
        // initiate http request
        let http = new XMLHttpRequest();
        http.open('GET',`https://www.googleapis.com/customsearch/v1?key=${googleApiKey}&cx=${googleCx}&q=${keyword}&cr=${country}`);
        http.onload = ()=>{
            if(http.status===200){
                let data = JSON.parse(http.responseText);
                console.log(data)
            }else{
                return 'http Error';
            }
        }
        http.send();
    }
   
}


